# Zoie Lind Writing Portfolio

A full responsive writing portfolio based on the approved soft editorial mockup: black header, hot-pink accents, cream/blush background, gold details, and a lily hero scene.

## Files
- `index.html` — website structure
- `style.css` — full visual design
- `script.js` — writing data, search, filters, dark mode, scroll animations

## How to edit
- Change writing titles/excerpts/full text inside `script.js`.
- Change contact email and Instagram in `index.html`.
- Replace the `Author Photo` placeholder in the About section with your own image later.

## Preview
Open `index.html` in a browser or upload the folder to CodeSandbox, Replit, Netlify, Vercel, or GitHub Pages.
